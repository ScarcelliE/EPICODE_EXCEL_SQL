CREATE DATABASE  IF NOT EXISTS `epicode_esecizio_w6d1` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `epicode_esecizio_w6d1`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: epicode_esecizio_w6d1
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `collocazione_videogico`
--

DROP TABLE IF EXISTS `collocazione_videogico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collocazione_videogico` (
  `cv_id` int NOT NULL AUTO_INCREMENT,
  `codice_store` int DEFAULT NULL,
  `titolo` varchar(255) DEFAULT NULL,
  `sviluppatore` varchar(255) DEFAULT NULL,
  `numero_copie` int DEFAULT NULL,
  PRIMARY KEY (`cv_id`),
  UNIQUE KEY `cv_id` (`cv_id`),
  KEY `codice_store` (`codice_store`),
  KEY `titolo` (`titolo`,`sviluppatore`),
  CONSTRAINT `collocazione_videogico_ibfk_1` FOREIGN KEY (`codice_store`) REFERENCES `store` (`codice_store`),
  CONSTRAINT `collocazione_videogico_ibfk_2` FOREIGN KEY (`titolo`, `sviluppatore`) REFERENCES `videogioco` (`titolo`, `sviluppatore`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collocazione_videogico`
--

LOCK TABLES `collocazione_videogico` WRITE;
/*!40000 ALTER TABLE `collocazione_videogico` DISABLE KEYS */;
INSERT INTO `collocazione_videogico` VALUES (1,1,'Fifa 2023','EA Sports',2),(2,2,'Fifa 2023','EA Sports',3),(3,3,'Fifa 2023','EA Sports',1),(4,4,'Fifa 2023','EA Sports',2),(5,5,'Fifa 2023','EA Sports',3),(6,6,'Fifa 2023','EA Sports',2),(7,7,'Fifa 2023','EA Sports',1),(8,8,'Fifa 2023','EA Sports',3),(9,9,'Fifa 2023','EA Sports',1),(10,10,'Fifa 2023','EA Sports',1),(11,1,'Super Mario Odyssey','Nintendo',1),(12,2,'Super Mario Odyssey','Nintendo',3),(13,3,'Super Mario Odyssey','Nintendo',2),(14,4,'Super Mario Odyssey','Nintendo',1),(15,5,'Super Mario Odyssey','Nintendo',1),(16,6,'Super Mario Odyssey','Nintendo',2),(17,7,'Super Mario Odyssey','Nintendo',2),(18,8,'Super Mario Odyssey','Nintendo',3),(19,9,'Super Mario Odyssey','Nintendo',1),(20,10,'Super Mario Odyssey','Nintendo',1),(21,1,'The Last of Us Part II','Naughty Dog',1),(22,2,'The Last of Us Part II','Naughty Dog',1),(23,3,'Cyberpunk 2077','CD Projekt Red',1),(24,4,'Cyberpunk 2077','CD Projekt Red',1),(25,5,'Animal Crossing: New Horizons','Nintendo',2),(26,6,'Animal Crossing: New Horizons','Nintendo',2),(27,7,'Call of Duty: Warzone','Infinity Ward',1),(28,8,'The Legend of Zelda: Breath of the Wild','Nintendo',2),(29,9,'The Legend of Zelda: Breath of the Wild','Nintendo',2),(30,10,'Fortnite','Epic Games',1),(31,1,'Red Dead Redemption 2','Rockstar Games',1),(32,2,'Assassin\'s Creed: Valhalla','Ubisoft',1);
/*!40000 ALTER TABLE `collocazione_videogico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `impiegato`
--

DROP TABLE IF EXISTS `impiegato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `impiegato` (
  `codice_fiscale` varchar(255) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `titolo_studio` varchar(255) DEFAULT NULL,
  `recapito` varchar(255) DEFAULT NULL,
  UNIQUE KEY `codice_fiscale` (`codice_fiscale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `impiegato`
--

LOCK TABLES `impiegato` WRITE;
/*!40000 ALTER TABLE `impiegato` DISABLE KEYS */;
INSERT INTO `impiegato` VALUES ('ABC12345XYZ67890','Mario	Rossi','Laurea	in	Economia','mario.rossi@email.com'),('BCD67890XYZ12345','Elena	Santoro','Laurea	in	Lettere','elena.santoro@email.com'),('DEF67890XYZ12345','Anna	Verdi','Diploma	di	Ragioneria','anna.verdi@email.com'),('GHI12345XYZ67890','Luigi	Bianchi','Laurea	in	Informatica','luigi.bianchi@email.com'),('JKL67890XYZ12345','Laura	Neri','Laurea	in	Lingue','laura.neri@email.com'),('MNO12345XYZ67890','Andrea	Moretti','Diploma	di	Geometra','andrea.moretti@email.com'),('PQR67890XYZ12345','Giulia	Ferrara','Laurea	in	Psicologia','giulia.ferrara@email.com'),('STU12345XYZ67890','Marco	Esposito','Diploma	di	Elettronica','marco.esposito@email.com'),('VWX67890XYZ12345','Sara	Romano','Laurea	in	Giurisprudenza','sara.romano@email.com'),('YZA12345XYZ67890','Roberto	De Luca','Diploma	di	Informatica','roberto.deluca@email.com');
/*!40000 ALTER TABLE `impiegato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servizio_impiegato`
--

DROP TABLE IF EXISTS `servizio_impiegato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servizio_impiegato` (
  `codice_fiscale` varchar(255) NOT NULL,
  `codice_store` int NOT NULL,
  `data_inizio` date NOT NULL,
  `data_fine` date DEFAULT NULL,
  `carica` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`codice_fiscale`,`codice_store`,`data_inizio`),
  UNIQUE KEY `codice_fiscale` (`codice_fiscale`,`codice_store`,`data_inizio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servizio_impiegato`
--

LOCK TABLES `servizio_impiegato` WRITE;
/*!40000 ALTER TABLE `servizio_impiegato` DISABLE KEYS */;
INSERT INTO `servizio_impiegato` VALUES ('ABC12345XYZ67890',1,'2023-01-01','2023-12-31','Cassiere'),('BCD67890XYZ12345',10,'2023-10-01','2023-03-31','Cassiere'),('DEF67890XYZ12345',2,'2023-02-01','2023-11-30','Commesso'),('GHI12345XYZ67890',3,'2023-03-01','2023-10-31','Magazziniere'),('JKL67890XYZ12345',4,'2023-04-01','2023-09-30','Addetto alle vendite'),('MNO12345XYZ67890',5,'2023-05-01','2023-08-31','Addetto alle pulizie'),('PQR67890XYZ12345',6,'2023-06-01','2023-07-31','Commesso'),('STU12345XYZ67890',7,'2023-07-01','2023-06-30','Commesso'),('VWX67890XYZ12345',8,'2023-08-01','2023-05-31','Cassiere'),('YZA12345XYZ67890',9,'2023-09-01','2023-04-30','Cassiere');
/*!40000 ALTER TABLE `servizio_impiegato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store`
--

DROP TABLE IF EXISTS `store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store` (
  `codice_store` int NOT NULL,
  `indirizzo_fisico` varchar(255) DEFAULT NULL,
  `numero_telefono` varchar(255) DEFAULT NULL,
  UNIQUE KEY `codice_store` (`codice_store`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store`
--

LOCK TABLES `store` WRITE;
/*!40000 ALTER TABLE `store` DISABLE KEYS */;
INSERT INTO `store` VALUES (1,'Via Roma 123, Milano','+39021234567'),(2,'Corso Italia 456, Roma','+39067654321'),(3,'Piazza San Marco 789, Venezia','+390419876543'),(4,'Viale degli Ulivi 234, Napoli','+390813456789'),(5,'Via Torino 567, Torino','+390118765432'),(6,'Corso Vittorio Emanuele 890, Firenze','+390552345678'),(7,'Piazza del Duomo 123, Bologna','+390518765432'),(8,'Via Garibaldi 456, Genova','+390102345678'),(9,'Lungarno Mediceo 789, Pisa','+390508765432'),(10,'Corso Cavour 101, Palermo','+390912345678');
/*!40000 ALTER TABLE `store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `videogioco`
--

DROP TABLE IF EXISTS `videogioco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `videogioco` (
  `titolo` varchar(255) NOT NULL,
  `sviluppatore` varchar(255) NOT NULL,
  `anno_distribuzione` year DEFAULT NULL,
  `costo_acquisto` double DEFAULT NULL,
  `genere` varchar(255) DEFAULT NULL,
  `remake_di` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`titolo`,`sviluppatore`),
  UNIQUE KEY `titolo` (`titolo`,`sviluppatore`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videogioco`
--

LOCK TABLES `videogioco` WRITE;
/*!40000 ALTER TABLE `videogioco` DISABLE KEYS */;
INSERT INTO `videogioco` VALUES ('Animal Crossing: New Horizons','Nintendo',2020,54.99,'Simulation',NULL),('Assassin\'s Creed: Valhalla','Ubisoft',2020,59.99,'Action',NULL),('Call of Duty: Warzone','Infinity Ward',2020,0,'FPS',NULL),('Cyberpunk 2077','CD Projekt Red',2020,49.99,'RPG',NULL),('Fifa 2023','EA Sports',2023,49.99,'Calcio',NULL),('Fortnite','Epic Games',2017,0,'Battle Royale',NULL),('Red Dead Redemption 2','Rockstar Games',2018,39.99,'Action-Adventure',NULL),('Super Mario Odyssey','Nintendo',2017,39.99,'Platform',NULL),('The Last of Us Part II','Naughty Dog',2020,69.99,'Action',NULL),('The Legend of Zelda: Breath of the Wild','Nintendo',2017,59.99,'Action-Adventure',NULL);
/*!40000 ALTER TABLE `videogioco` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-09 14:47:26
