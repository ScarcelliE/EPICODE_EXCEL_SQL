-- Esercizio 1

-- Seleziona tutti gli impiegati con una laurea in Economia.
select 
nome,
titolo_studio,
recapito
from Impiegato where titolo_studio='Laurea	in	Economia';


-- Seleziona gli impiegati che lavorano come Cassiere o che hanno un Diploma di Informatica.
select 
i.nome,
i.titolo_studio,
i.recapito,
s.carica
from
impiegato as i inner join servizio_impiegato as s
on
i.codice_fiscale=s.codice_fiscale
where
i.titolo_studio='Diploma	di	Informatica' or s.carica='Cassiere';


-- Seleziona i nomi e i titoli degli impiegati che hanno iniziato a lavorare dopo il 1 gennaio 2023.
select 
i.nome,
i.titolo_studio,
s.data_inizio
from
impiegato as i inner join servizio_impiegato as s
on
i.codice_fiscale=s.codice_fiscale
where
s.data_inizio>'2023-01-01';


-- Seleziona i titoli di studio distinti tra gli impiegati.
select distinct titolo_studio from impiegato;


-- Seleziona gli impiegati con un titolo di studio diverso da "Laurea in Economia".
select
nome,
titolo_studio
recapito
from
impiegato where titolo_studio!='Laurea	in	Economia';


-- Seleziona gli impiegati che hanno iniziato a lavorare prima del 1 luglio 2023 e sono Commessi.
select 
i.nome,
i.titolo_studio,
s.data_inizio,
s.carica
from
impiegato as i inner join servizio_impiegato as s
on
i.codice_fiscale=s.codice_fiscale
where
s.data_inizio<'2023-07-01' and s.carica='Commesso';


-- Seleziona i titoli e gli sviluppatori dei videogiochi distribuiti nel 2020.
select 
titolo,
sviluppatore,
anno_distribuzione
from
videogioco where anno_distribuzione='2020';


/* Seleziona i titoli dei videogiochi disponibili nei settori 1 o 3 del negozio 5.  
   Non considero la richiesta del settore in quanto manca la relazione della collocazione dei videogiochi nei settori. 
   Andrebbe aggiunto un altro campo settore nella tabella collocazione_videogico e fare la condizione (numero_settore in (1,3), per estrapolare.
   In alternativa tabella relazione con id_settore, id_store, videogioco, numero_settore,
*/
select 
titolo,
codice_store,
numero_copie as copie_disponibili
from
collocazione_videogico where codice_store='5';


-- Seleziona i negozi con più di 20 copie disponibili di almeno un videogioco.
select 
codice_store,
numero_copie as copie_disponibili
from
collocazione_videogico where numero_copie>'20';

-- Esercizio 2

-- Seleziona tutti i prodotti con un prezzo superiore a 50 euro dalla tabella Prodotti. 
select * 
from prodotto where prezzo>'50';


-- Seleziona tutte le email dei clienti il cui nome inizia con la lettera 'A' dalla tabella Clienti. 
select distinct email
from cliente where email like 'a%';


-- Seleziona tutti gli ordini con una quantità maggiore di 10 o con un importo totale inferiore a 100 euro dalla tabella Ordini. 
select 
o.id_ordine,
o.quantità,
p.prezzo,
o.quantità*p.prezzo as prezzo_totale
from ordine as o inner join prodotto as p
on o.id_prodotto=p.id_prodotto where quantità>'10' or o.quantità*p.prezzo<'100';


-- Seleziona tutti i prezzi dei prodotti il cui nome contiene la parola 'tech' indipendentemente dalla posizione nella tabella Prodotti. 
select
nome_prodotto,
prezzo 
from prodotto where nome_prodotto like '%tech%';


-- Seleziona tutti i clienti che non hanno un indirizzo email nella tabella Clienti.
select
*
from cliente where email is null;


-- Seleziona tutti i prodotti il cui nome inizia con 'M' e termina con 'e' indipendentemente dalla lunghezza della parola nella tabella Prodotti.
select
nome_prodotto
from prodotto where nome_prodotto like 'M%e';
