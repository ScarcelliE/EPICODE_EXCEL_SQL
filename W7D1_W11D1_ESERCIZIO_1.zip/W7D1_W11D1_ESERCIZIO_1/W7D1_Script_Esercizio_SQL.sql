-- Pratica 1
-- Esercizio 1
-- Fate un elenco di tutte le tabelle

SELECT 
    TABLE_NAME
FROM
    INFORMATION_SCHEMA.TABLES
WHERE
    TABLE_SCHEMA = 'chinnok';
-- Seconda possibile svolgimento
SHOW FULL TABLES IN chinnok;

/* ELENCO TABELLE con attributi:
- Album (`AlbumId`, `Title`, `ArtistId`);
- Artist (`ArtistId`, `Name`);
- Customer (`CustomerId`, 'FirstName`, `LastName`, `Company`, `Address`), `City`, `State`, `Country`, `PostalCode`, `Phone`, `Fax`, `Email`, `SupportRepId`);
- Employee (`EmployeeId` , `LastName`, `FirstName`, `Title`, `ReportsTo`, `BirthDate`, `HireDate`, 'Address`, `City`, `State`, `Country`, `PostalCode`, `Phone`, `Fax`, `Email`);
- Genre ( `GenreId`, `Name`);
- Invoice (`InvoiceId`, `CustomerId`, `InvoiceDate`, `BillingAddress`, `BillingCity`, `BillingState`, `BillingCountry`, `BillingPostalCode`, `Total`);
- InvoiceLine (`InvoiceLineId`, `InvoiceId`, `TrackId`, 'UnitPrice`, `Quantity`);
- MediaType (`MediaTypeId`, 'Name`);
- Playlist (`PlaylistId`, `Name`);
- PlaylistTrack (`PlaylistId`, `TrackId`);
- Track (`TrackId`, `Name`, `AlbumId`, `MediaTypeId`, `GenreId`, `Composer`, `Milliseconds`, `Bytes`, `UnitPrice`);
*/

-- Visualizzate le prime 10 righe della tabella Album

SELECT 
    *
FROM
    album
WHERE
    AlbumId BETWEEN 1 AND 10; 
-- Secondo possibile svolgimento
SELECT 
    *
FROM
    album
ORDER BY AlbumId
LIMIT 10;
    
-- Trovate il numero totale di canzoni della tabella Tracks 

SELECT 
	COUNT(name) TOT_CANZONI,
    COUNT(DISTINCT name) TOT_CANZONI_DISTINTE
FROM
    track;
    -- Risultato 3247 Nomi distinti
 
 
-- Trovate i diversi generi presenti nella tabella Genre

SELECT 
    DISTINCT(name)
FROM
    genre;

-- Esercizio 2
-- Recuperate il nome di tutte le tracce e del genere associato

SELECT DISTINCT
    t.name, G.Name
FROM
    track t
        INNER JOIN
    genre g ON t.GenreId = g.GenreId;


-- Esercizio 3 
-- Recuperate il nome di tutti gli artisti che hanno almeno un album nel database. Esistono artisti senza album nel database?

SELECT DISTINCT
    artist.Name
FROM
    artist
        INNER JOIN
    album ON artist.ArtistId = album.ArtistId;   
    
 -- Artisti senza album
SELECT 
    artist.name AS Artista_Non_Album
FROM
    artist
        LEFT JOIN
    album ON artist.ArtistId = album.ArtistId
WHERE
    album.title IS NULL;
   
-- Esercizio 4 
-- Recuperate il nome di tutte le tracce, del genere associato e della tipologia di media. Esiste un modo per recuperare il nome della tipologia di media? 

SELECT
    t.name, g.name, mt.name
FROM
    track t
        JOIN
    genre g ON t.GenreId = g.GenreId
		JOIN
    mediatype mt ON t.mediatypeid = mt.mediatypeid;


-- Esercizio 5 
-- Elencate i nomi di tutti gli artisti e dei loro album.  

SELECT 
    artist.Name, album.title
FROM
    artist
        INNER JOIN
    album ON artist.ArtistId = album.ArtistId;

-- Pratica 2
-- Esercizio 1 
-- Recuperate tutte le tracce che abbiano come genere “Pop” o “Rock”

SELECT DISTINCT
    t.name
FROM
    track t
        JOIN
    genre g ON t.genreid = g.genreid
WHERE
    g.name = 'pop' OR g.name = 'rock';

-- Esercizio 2 
-- Elencate tutti gli artisti e/o gli album che inizino con la lettera “A”. 

SELECT 
    al.title,
    ar.name
FROM
    album al
       RIGHT JOIN
    artist ar ON al.ArtistId = ar.ArtistId
WHERE al.title like 'a%' OR ar.name like 'a%';

-- Esercizio 3 
-- Recuperate i nomi dei dipendenti nati prima dell’anno 1970. 

SELECT 
    firstname,
    lastname,
    BirthDate
FROM
    employee WHERE BirthDate<date("1970-01-01");

-- Esercizio 4 Elencate tutte le tracce che hanno come genere “Jazz” o che durano meno di 3 minuti

SELECT DISTINCT
    Name
FROM
    track
WHERE
    genreid = 2 OR milliseconds < 180000;

-- Esercizio 5 Recuperate tutte le tracce più lunghe della durata media

SELECT 
    name, milliseconds
FROM
    track
WHERE
    milliseconds > (SELECT 
            AVG(milliseconds)
        FROM
            track);


-- Esercizio 6 Individuate i generi che hanno tracce con una durata media maggiore di 4 minuti

SELECT DISTINCT
    g.NAME
FROM
    track t
        LEFT JOIN
    genre g ON t.genreid = g.genreid
WHERE
    milliseconds > 240000;
    
-- Esercizio 7 Individuate gli artisti che hanno rilasciato più di un album

SELECT 
    ar.name, COUNT(al.title) AS num_album
FROM
    artist ar
        JOIN
    album al ON ar.artistid = al.artistid
GROUP BY ar.name
HAVING num_album > 1
ORDER BY num_album DESC;


-- Esercizio 8 Trovate la traccia più lunga in ogni album

SELECT TITLE, NAME, MILLISECONDS
FROM (SELECT TITLE, T.NAME, MILLISECONDS, ROW_NUMBER() OVER( PARTITION BY TITLE ORDER BY  T.MILLISECONDS DESC) AS RN
FROM TRACK AS T
JOIN ALBUM AS A ON T.ALBUMID=A.ALBUMID) B
WHERE RN=1;

-- Esercizio 8 Individuate la durata media delle tracce per ogni album 

SELECT 
    title, AVG(milliseconds) AS avg_track
FROM
    track t
        LEFT JOIN
    album a ON t.albumid = a.albumid
GROUP BY title
ORDER BY avg_track DESC;

-- Esercizio 9 Individuate gli album che hanno più di 20 tracce e mostrate il nome dell’album e il numero di tracce in esso contenute.

SELECT 
    title, COUNT(DISTINCT track.name) AS num_track
FROM
    track
        LEFT JOIN
    album ON track.albumid = album.albumid
GROUP BY title
HAVING num_track > 20
ORDER BY num_track DESC;
