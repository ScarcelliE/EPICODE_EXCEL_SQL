-- Esercizio 1 
-- Elencate il numero di tracce per ogni genere in ordine discendente, escludendo quei generi che hanno meno di 10 tracce.

SELECT 
    g.genreid,
    g.name,
    COUNT(DISTINCT t.name) AS num_tracce_per_genere
FROM
    track t
        JOIN
    genre g ON t.genreid = g.genreid
GROUP BY g.genreid , g.name
HAVING num_tracce_per_genere > 10
ORDER BY num_tracce_per_genere DESC; 


-- Esercizio 2 
-- Trovate le tre canzoni più costose.

SELECT 
    t.name, t.unitPrice
FROM
    track t
WHERE
    t.unitprice = (SELECT MAX(unitprice)
        FROM
            track)
ORDER BY t.name
LIMIT 3;


-- Esercizio 3 
-- Elencate gli artisti che hanno canzoni più lunghe di 6 minuti.

SELECT DISTINCT
    ar.name
FROM
    track t
        JOIN
    album al ON t.albumid = al.albumid
        LEFT JOIN
    artist ar ON ar.artistid = al.albumid
WHERE
    t.milliseconds > 360000;


-- Esercizio 4 
-- Individuate la durata media delle tracce per ogni genere.

SELECT 
    g.name, AVG(milliseconds) AS durata_media_tracce
FROM
    track t 
        LEFT JOIN
    genre g ON t.genreid = g.genreid
GROUP BY g.name
ORDER BY durata_media_tracce DESC;


-- Esercizio 5 
-- Elencate tutte le canzoni con la parola “Love” nel titolo, ordinandole alfabeticamente prima per genere e poi per nome.

SELECT 
    g.name Genere, t.name Titolo
FROM
    track t
        JOIN
    genre g ON t.genreid = g.genreid
WHERE
    t.name LIKE '%love%'
ORDER BY g.name, t.name;

-- Esercizio 6 
-- Trovate il costo medio per ogni tipologia di media.

SELECT 
    mt.name, CAST(AVG(unitprice) AS DECIMAL(10,3)) AS costo_medio
FROM
    track t
        JOIN
    mediatype mt ON t.mediatypeid = mt.mediatypeid
GROUP BY mt.name
ORDER BY costo_medio DESC;


-- Esercizio 7 
-- Individuate il genere con più tracce. 

SELECT 
    g.name Genere, COUNT(t.TrackId) AS num_traccie
FROM
    track t
        JOIN
    genre g ON t.genreid = g.genreid
GROUP BY g.name
LIMIT 1;

-- Esercizio 8 
-- Trovate gli artisti che hanno lo stesso numero di album dei Rolling Stones. 

-- numero di album dei Rolling Stones
SELECT 
    a.num_album
FROM
    (SELECT 
        artist.name, COUNT(album.albumid) AS num_album
    FROM
        album
    JOIN artist ON album.artistid = artist.artistid
    GROUP BY artist.name
    HAVING artist.name LIKE '%Rolling Stones%') a;

-- numero album di tutti i cantanti
SELECT
    artist.name, COUNT(album.albumid) AS num_album
FROM
    album
        JOIN
    artist ON album.artistid = artist.artistid
GROUP BY artist.name;
-- conclusione
SELECT 
    *	
FROM
    (SELECT 
        artist.name, COUNT(album.albumid) AS num_album
    FROM
        album
    JOIN artist ON album.artistid = artist.artistid
    GROUP BY artist.name) AS a
WHERE
    a.num_album = (SELECT 
            a.num_album
        FROM
            (SELECT 
                artist.name, COUNT(album.albumid) AS num_album
            FROM
                album
            JOIN artist ON album.artistid = artist.artistid
            GROUP BY artist.name
            HAVING artist.name LIKE '%Rolling Stones%') a);
-- alternativa
SELECT 
    AR.NAME, COUNT(AL.TITLE) AS NUM_ALBUM
FROM
    ARTIST AR
        LEFT JOIN
    ALBUM AL ON AL.ARTISTID = AR.ARTISTID
GROUP BY AR.NAME
HAVING NUM_ALBUM = (SELECT 
        COUNT(AL.TITLE) AS NUM_ALBUM
    FROM
        ARTIST AR
            LEFT JOIN
        ALBUM AL ON AL.ARTISTID = AR.ARTISTID
    WHERE
        AR.NAME = 'The Rolling Stones');

-- Esercizio 9 
-- Trovate l’artista con l’album più costoso.

SELECT 
    ar.name, al.title, SUM(t.unitprice) costo_album
FROM
    track t
        JOIN
    album al ON t.albumid = al.albumid
        JOIN
    artist ar ON al.artistid = ar.artistid
GROUP BY ar.name , al.title
ORDER BY costo_album DESC
LIMIT 1;
