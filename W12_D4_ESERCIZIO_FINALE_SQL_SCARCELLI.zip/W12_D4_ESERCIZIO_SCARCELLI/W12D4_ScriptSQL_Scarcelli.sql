-- Creazione Schema
CREATE SCHEMA IF NOT EXISTS toys_group_Scarcelli_Ernesto;
USE toys_group_Scarcelli_Ernesto;

-- Creazione Tabelle
CREATE TABLE IF NOT EXISTS product (
    id_prodotto INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL UNIQUE,
    nome VARCHAR(255) NOT NULL,
    categoria VARCHAR(255) NOT NULL,
    prezzo_unitario DOUBLE (10,2)
)
;
CREATE TABLE IF NOT EXISTS region (
id_regione INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL UNIQUE,
nome_regione VARCHAR(255) NOT NULL,
stato VARCHAR(255),
area_geografica VARCHAR(255)
)
;
CREATE TABLE IF NOT EXISTS sales (
    id_vendita INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL UNIQUE,
    id_prodotto INTEGER NOT NULL,
    id_regione INTEGER NOT NULL,
    data_vendita DATE NOT NULL,
    quantità_venduta INTEGER,
    totale_venduto DOUBLE (10,2),
    FOREIGN KEY (id_prodotto)
        REFERENCES product (id_prodotto),
    FOREIGN KEY (id_regione)
        REFERENCES region (id_regione)
)
;

-- Popolamento tabelle
INSERT INTO product  (nome, categoria, prezzo_unitario) VALUES
('barbie', 'bambole', '29.90'),
('frozen', 'bambole', '19.90'),
('costruzioni_3d', 'costruzioni', '19.90'),
('cars', 'automobili', '9.90'),
('ferrari', 'automobili', '19.90'),
('paesaggio_dolomiti', 'puzzel', '19.90'),
('risiko', 'società', null)
;
INSERT INTO region (nome_regione, stato, area_geografica) VALUES 
('Lombardia','Italia','Europa'),
('California','Stati Uniti','America'),
('Mongolia','Cina','Asia'),
('Casablanca','Marocco','Afirca')
;
INSERT INTO sales( id_prodotto, id_regione, data_vendita, quantità_venduta, totale_venduto)  VALUES 
('1','1','2023-02-20','2','59.80'),
('1','2','2024-02-23','1','29.90'),
('2','3','2024-02-21','1','19.90'),
('2','1','2024-02-22','1','19.90'),
('3','1','2023-02-22','1','19.90'),
('3','3','2024-02-23','2','39.80'),
('4','1','2024-02-22','1','9.90'),
('6','2','2024-02-23','3','59.70')
;

-- 1. Verificare che i campi definiti come PK siano univoci. 
-- Le PK sono unique, inoltre verifico le caratteristiche degli attributi creati nelle tabelle
SHOW COLUMNS FROM product; -- id_prodotto PK
SHOW COLUMNS FROM region; -- id_regione PK
SHOW COLUMNS FROM sales; -- id_vendite PK

-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
SELECT 
	p.id_prodotto,
    p.nome,
    YEAR(data_vendita) AS anno,
    SUM(s.totale_venduto) AS fatturato
FROM
    sales s
        JOIN
    product p ON s.id_prodotto = p.id_prodotto
GROUP BY p.id_prodotto, p.nome, anno;

-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
SELECT 
       r.stato,
    YEAR(data_vendita) AS anno,
    SUM(totale_venduto) fatturato
FROM
    sales s
        JOIN
    region r ON s.id_regione = r.id_regione
GROUP BY r.stato , anno
ORDER BY anno , fatturato DESC;

-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
-- Creo una vista per individuare per ogni categorie il numero di prodotti venduti 
CREATE VIEW numero_articoli_venduti AS
SELECT 
    p.categoria,
    SUM(s.quantità_venduta) AS n_a_v
    FROM
    sales s
        JOIN
    product p ON s.id_prodotto = p.id_prodotto
GROUP BY p.categoria;
-- seleziono la/e categoria/e con il massimo di articoli venduti, quindi di maggiore richiesta dal mercato
SELECT categoria
FROM numero_articoli_venduti
WHERE n_a_v=(
SELECT MAX(n_a_v) FROM numero_articoli_venduti);

-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
-- primo medoto: tutti i prodotti che non sono compresi in quelli che hanno avuto una vendita 
SELECT *
FROM product p
WHERE p.id_prodotto NOT IN ( SELECT s.id_prodotto
FROM sales s)
;
-- secondo medoto: i prodotti diversi da tutti quelli che hanno avuto una vendita
SELECT *
FROM product p
WHERE p.id_prodotto <> ALL ( SELECT s.id_prodotto
FROM sales s)
;
-- terzo medoto left join con condizione di vendita che è null
SELECT 
    p.*
FROM
    product p
        LEFT JOIN
    sales s ON p.id_prodotto = s.id_prodotto
WHERE
    s.id_vendita IS NULL;
 
-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
SELECT 
    p.nome, MAX(data_vendita) data_vendita_più_recente
FROM
    sales s
        JOIN
    product p ON s.id_prodotto = p.id_prodotto
GROUP BY p.nome

