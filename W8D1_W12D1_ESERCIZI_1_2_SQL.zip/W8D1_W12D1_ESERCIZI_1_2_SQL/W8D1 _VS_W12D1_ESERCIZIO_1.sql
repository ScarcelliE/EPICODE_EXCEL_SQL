-- Esercizio 1 
-- Effettuate un’esplorazione preliminare del database. Di cosa si tratta? Quante e quali tabelle contiene? Fate in modo di avere un’idea abbastanza chiara riguardo a con cosa state lavorando. 

SELECT
TABLE_NAME
FROM
INFORMATION_SCHEMA.TABLES
WHERE
TABLE_SCHEMA='sakila';

SHOW COLUMNS FROM actor;
-- sakila è composto da 23 tabelle che rappresenta un db con la descrizione di film e gestione di vendita degli stessi in deu store dell'Ausrtralia e Canada

SELECT * FROM actor;
SELECT * FROM actor_info;
SELECT * FROM address;
SELECT * FROM category;
SELECT * FROM city;
SELECT * FROM country;
SELECT * FROM customer;
SELECT * FROM customer_list;
SELECT * FROM film;
SELECT * FROM film_actor;
SELECT * FROM film_category;
SELECT * FROM film_list;
SELECT * FROM film_text;
SELECT * FROM inventory;
SELECT * FROM language;
SELECT * FROM nicer_but_slower_film_list;
SELECT * FROM payment;
SELECT * FROM rental;
SELECT * FROM sales_by_film_category;
SELECT * FROM sales_by_store;
SELECT * FROM staff;
SELECT * FROM staff_list;
SELECT * FROM store;

-- Esercizio 2 
-- Scoprite quanti clienti si sono registrati nel 2006. 

SELECT 
    COUNT(*) AS Clienti_registrati_2006
FROM
    customer
WHERE
    YEAR(create_date) = '2006';

-- Esercizio 3 
-- Trovate il numero totale di noleggi effettuati il giorno 1/1/2006. 

SELECT 
    COUNT(*) AS Noleggi_del_1_1_2006
FROM
    rental
WHERE
    DATE(rental_date) = '2006-01-01';

-- Esercizio 4 
-- Elencate tutti i film noleggiati nell’ultima settimana e tutte le informazioni legate al cliente che li ha noleggiati. 

-- ultima settimana 2006-02-14
SELECT MAX(rental_date)
FROM rental;
-- 7 giorni prima 2006-02-08  
SELECT 
    f.title, c.*
FROM
    film f
        JOIN
    inventory i ON f.film_id = i.film_id
        JOIN
    rental r ON i.inventory_id = r.inventory_id
        JOIN
    customer c ON r.customer_id = c.customer_id
WHERE
    DATE(r.rental_date) BETWEEN DATE('2006-02-08') AND DATE('2006-02-14');


-- Esercizio 5 
-- Calcolate la durata media del noleggio per ogni categoria di film. 

SELECT 
    dn.name AS categoria,
    CAST(AVG(dn.durata_noleggi) AS DECIMAL (10 , 2 )) AS durata_media_noleggi
FROM
    (SELECT 
        c.name, DATEDIFF(return_date, rental_date) AS durata_noleggi
    FROM
        rental r
    JOIN inventory i ON r.inventory_id = i.inventory_id
    JOIN film_category fc ON i.film_id = fc.film_id
    JOIN category c ON c.category_id = fc.category_id) AS dn
GROUP BY dn.name;

-- durata noleggi
SELECT 
    CAST(AVG(durata_noleggi) AS DECIMAL (10 , 0 )) AS durata_media_noleggio
FROM
    (SELECT 
        DATEDIFF(return_date, rental_date) AS durata_noleggi
    FROM
        rental) b;
        
-- durata media da tabella film rental duration sempre 5 gg       
SELECT 
    CAST(AVG(rental_duration) AS DECIMAL(10,0)) AS durata_media_noleggio
FROM
    film;
    
-- Esercizio 6 
-- Trovate la durata del noleggio più lungo.

-- durata noleggi
SELECT 
    DATEDIFF(return_date, rental_date) AS durata_noleggi
FROM
    rental;
--  durata noleggi da differenza date
SELECT 
    MAX(durata_noleggi) AS durata_noleggio_massimo
FROM
    (SELECT 
        DATEDIFF(return_date, rental_date) AS durata_noleggi
    FROM
        rental) b;
-- durata noleggio massima da tabella film rental_duration 7 gg       
SELECT 
    MAX(rental_duration) AS durata_noleggio_massimo
FROM
    film;