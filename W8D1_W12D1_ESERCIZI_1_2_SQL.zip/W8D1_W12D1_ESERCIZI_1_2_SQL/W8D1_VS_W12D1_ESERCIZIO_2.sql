-- Esercizio 1 
-- Identificate tutti i clienti che non hanno effettuato nessun noleggio a gennaio 2006. 

-- Considero i clienti che non hanno effettuato noleggi a febbraio 2006, inquanto a gennaio sono nulli e quindi sarebbero tutti i clienti
-- I clienti che hanno effettuato noleggi a febbraio 2006
SELECT DISTINCT
    customer_id
FROM
    rental
WHERE
    DATE(rental_date) BETWEEN ('2006-02-01') AND DATE('2006-02-28');

-- Tutti i clienti eccetto quelli che hanno fatto noleggi a febbraio 2006 
SELECT 
    customer_id, first_name, last_name
FROM
    customer
WHERE
    customer_id NOT IN (SELECT DISTINCT
            customer_id
        FROM
            rental
        WHERE
            DATE(rental_date) BETWEEN ('2006-02-01') AND DATE('2006-02-28'));


-- Esercizio 2 
-- Elencate tutti i film che sono stati noleggiati più di 10 volte nell’ultimo quarto del 2005 

-- film noleggiati più di 1 volte (>10 niente) nel primo quarto del 2006, nell'ultimo 2005 non ho niente
SELECT 
    f.title, COUNT(*) numero_noleggi
FROM
    rental r
        JOIN
    inventory i ON r.inventory_id = i.inventory_id
        JOIN
    film f ON i.film_id = f.film_id
WHERE
    DATE(rental_date) BETWEEN DATE('2006-01-01') AND DATE('2006-03-31')
GROUP BY f.title
HAVING numero_noleggi > 1;


-- Esercizio 3 
-- Trovate il numero totale di noleggi effettuati il giorno 1/1/2006. 

SELECT 
    COUNT(*) AS numero_noleggi_01_01_2006
FROM
    rental
WHERE
    DATE(rental_date) = DATE('2006-01-01');


-- Esercizio 4 
-- Calcolate la somma degli incassi generati nei weekend (sabato e domenica). 


SELECT SUM(amount) Somma_incassi_weekend
FROM
  payment
WHERE
  DAYNAME(payment_date) IN ('Saturday' , 'Sunday');
    
 
-- Esercizio 5 
-- Individuate il cliente che ha speso di più in noleggi.


SELECT 
    c.customer_id,
    c.first_name,
    c.last_name,
    SUM(p.amount) tot_spesa_cliente
FROM
    payment p
        JOIN
    customer c ON c.customer_id = p.customer_id
GROUP BY c.customer_id , c.first_name , c.last_name
ORDER BY tot_spesa_cliente DESC
LIMIT 1;

-- Esercizio 6 
-- Elencate i 5 film con la maggior durata media di noleggio.

SELECT 
    title, 
    rental_duration -- AVG(rental_duration) AS durata_media_noleggi
FROM
    film
-- GROUP BY 1
ORDER BY rental_duration DESC
LIMIT 5;


-- Esercizio 7 
-- Calcolate il tempo medio tra due noleggi consecutivi da parte di un cliente. 

SELECT r1.customer_id, AVG(DATEDIFF(r2.rental_date,r1.rental_date)) AS date_diff
FROM rental r1
JOIN rental r2 ON r1.customer_id=r2.customer_id AND r2.rental_date>r1.rental_date
GROUP BY r1.customer_id;


-- Esercizio 8 Individuate il numero di noleggi per ogni mese del 2005. 

SELECT 
    MONTHNAME(rental_date) AS mese, COUNT(*) tot_noleggi_2005
FROM
    rental
WHERE
    YEAR(rental_date) = '2005'
GROUP BY mese;


-- Esercizio 9 Trovate i film che sono stati noleggiati almeno due volte lo stesso giorno. 

SELECT 
    f.title,
    DATE(return_date) data_noleggio,
    COUNT(*) numero_noleggi
FROM
    film f
        JOIN
    inventory i ON f.film_id = i.film_id
        JOIN
    rental r ON i.inventory_id = r.inventory_id
GROUP BY f.title , data_noleggio
HAVING numero_noleggi > 1;  

-- nomi dei film distinti 
SELECT DISTINCT(a.title)
FROM (SELECT 
    f.title,
    DATE(return_date) data_noleggio,
    COUNT(*) numero_noleggi
FROM
    film f
        JOIN
    inventory i ON f.film_id = i.film_id
        JOIN
    rental r ON i.inventory_id = r.inventory_id
GROUP BY f.title , data_noleggio
HAVING numero_noleggi > 1) a;  

 
-- Esercizio 10 Calcolate il tempo medio di noleggio.

SELECT 
    CAST(AVG(rental_duration) AS DECIMAL (10,2)) durata_media_noleggio
FROM
    film;



